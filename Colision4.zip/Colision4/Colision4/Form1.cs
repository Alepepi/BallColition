﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Colision4
{
    public partial class Form1 : Form
    {

        public Bitmap bmp;
        static Graphics g;
        List<Ball> pelota;
        static Random rand = new Random();

        public Form1()
        {
            InitializeComponent();

        }

        public void Init()
        {
            pelota = new List<Ball>();
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(bmp);
            pictureBox1.Image = bmp;

            for (int i = 0; i < 3; i++)
            {
                pelota.Add(new Ball(rand,pictureBox1.Size, i ));
            }
            
        }

        private void TIMER_Tick(object sender, EventArgs e)
        {
            g.Clear(Color.Black);
            Ball b;
            for (int i = 0; i < pelota.Count; i++)
            {
                pelota[i].Update(pelota);
                b = pelota[i];
                g.FillEllipse(new SolidBrush(pelota[i].c), b.x - b.sizeE / 2, b.y - b.sizeE / 2, b.sizeE, b.sizeE);

            }
            pictureBox1.Invalidate();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Init();
        }
    }
}
