﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace Colision4
{
    internal class Ball
    {
        public int x;
        public int y;
        public int velx;
        public int vely;
        public int index;
        static Size sp;
        public int sizeE;
        public Color c;


        public Ball(Random rand, Size size, int index)
        {
            x = rand.Next(0, 800);
            y = rand.Next(0, 450);
            velx = rand.Next(-30, 30);
            vely = rand.Next(-30, 30);
            sizeE = rand.Next(10, 15);
            sp = size;
            c = Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255));        }

        public void Update(List<Ball> balls)
        {
            x += velx;
            y += vely;

            if ((x - (sizeE / 2)) <= 0 || (x + (sizeE / 2)) >= sp.Width)
            {
                velx *= -1;
            }
            if ((y - (sizeE / 2)) <= 0 || (y + (sizeE / 2)) >= sp.Height)
            {
                vely *= -1;
            }
        }
    }
}
